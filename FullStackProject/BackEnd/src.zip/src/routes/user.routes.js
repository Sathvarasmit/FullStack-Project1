import {Router} from 'express'
import { registerUser } from '../controllers/user.controllers.js'
import { upload } from '../middlewares/multer.middleware.js'

const router = Router()
router.route("/register").post(
    upload.fields([
        {
            name: "avatar",
            maxCount: 1
        },
        {
            name: "coverImage",
            maxCount: 1
        }
    ]),
    registerUser
)

// at here we are going to use middleware multer before regesterUser method

export default router